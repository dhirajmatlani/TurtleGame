﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Turtle.Parse;
using Turtle.Payload;
using Turtle.Enum;
using Turtle.Factory;
using Turtle.Interface;

namespace TurtleTest
{
    [TestClass]
    public class IntegrationTest
    {
        [TestMethod]
        public void ShouldIgnoreCommandsBeforePlace()
        {
            IParse parser = new Parser();
            ICommandFactory commandFactory = new CommandFactory();
            Position currentPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            CommandPayload commandPayload = parser.Parse("MOVE");
            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Position newPosition = commandExecutor.Execute(commandPayload, currentPosition);

            Assert.AreEqual(-1, newPosition.Coordinates.X);
            Assert.AreEqual(-1, newPosition.Coordinates.Y);
            Assert.AreEqual(Direction.SomeWhere, newPosition.Direction);
        }

        [TestMethod]
        public void ShouldSetPlace()
        {
            IParse parser = new Parser();
            ICommandFactory commandFactory = new CommandFactory();
            Position currentPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            CommandPayload commandPayload = parser.Parse("PLACE 0,0,NORTH");
            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Position newPosition = commandExecutor.Execute(commandPayload, currentPosition);

            Assert.AreEqual(0, newPosition.Coordinates.X);
            Assert.AreEqual(0, newPosition.Coordinates.Y);
            Assert.AreEqual(Direction.North, newPosition.Direction);
        }

    }
}
