﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Turtle.Parse;
using Turtle.Payload;
using Turtle.Enum;
using Turtle.Factory;
using Turtle.Interface;
using Turtle.Commands;
using Turtle.Calculator;
using Turtle.Validator;
using Turtle.Payload;

namespace TurtleTest
{
    [TestClass]
    public class CommandFactoryTest
    {
        [TestMethod]
        public void ShouldReturnMoveCommandExecutor()
        {
            ICommandFactory commandFactory = new CommandFactory();
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Move;

            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Assert.AreEqual(typeof(MoveCommand), commandExecutor.GetType());
        }

        [TestMethod]
        public void ShouldReturnPlaceCommandExecutor()
        {
            ICommandFactory commandFactory = new CommandFactory();
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;

            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Assert.AreEqual(typeof(PlaceCommand), commandExecutor.GetType());
        }

        [TestMethod]
        public void ShouldReturnLeftCommandExecutor()
        {
            ICommandFactory commandFactory = new CommandFactory();
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Left;

            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Assert.AreEqual(typeof(LeftCommand), commandExecutor.GetType());
        }

        [TestMethod]
        public void ShouldReturnRightCommandExecutor()
        {
            ICommandFactory commandFactory = new CommandFactory();
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Right;

            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Assert.AreEqual(typeof(RightCommand), commandExecutor.GetType());
        }

        [TestMethod]
        public void ShouldReturnReportCommandExecutor()
        {
            ICommandFactory commandFactory = new CommandFactory();
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Report;

            ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
            Assert.AreEqual(typeof(ReportCommand), commandExecutor.GetType());
        }
    }
}
