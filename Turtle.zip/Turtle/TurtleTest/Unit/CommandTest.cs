﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Turtle.Parse;
using Turtle.Payload;
using Turtle.Enum;
using Turtle.Factory;
using Turtle.Interface;
using Turtle.Commands;
using Turtle.Calculator;
using Turtle.Validator;
using Turtle.Payload;

namespace TurtleTest
{
    [TestClass]
    public class CommandTest
    {

        [TestMethod]
        public void ShouldExecutePlace()
        {
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;
            commandPayload.Position = new Position();
            commandPayload.Position.Coordinates.X = 0;
            commandPayload.Position.Coordinates.Y = 0;
            commandPayload.Position.Direction = Direction.North;

            Position position = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            ICommand commandExecutor = new PlaceCommand(new PlaceCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            Assert.AreEqual(0, position.Coordinates.X);
            Assert.AreEqual(0, position.Coordinates.Y);
            Assert.AreEqual(Direction.North, position.Direction);
        }

        [TestMethod]
        public void ShouldExecuteMove()
        {
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;
            commandPayload.Position = new Position();
            commandPayload.Position.Coordinates.X = 0;
            commandPayload.Position.Coordinates.Y = 0;
            commandPayload.Position.Direction = Direction.North;

            Position position = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            ICommand commandExecutor = new PlaceCommand(new PlaceCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            commandPayload.Command = Command.Move;
            commandExecutor = new MoveCommand(new MoveCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            Assert.AreEqual(0, position.Coordinates.X);
            Assert.AreEqual(1, position.Coordinates.Y);
            Assert.AreEqual(Direction.North, position.Direction);
        }

        [TestMethod]
        public void ShouldExecuteLeft()
        {
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;
            commandPayload.Position = new Position();
            commandPayload.Position.Coordinates.X = 0;
            commandPayload.Position.Coordinates.Y = 0;
            commandPayload.Position.Direction = Direction.North;

            Position position = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            ICommand commandExecutor = new PlaceCommand(new PlaceCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            commandPayload.Command = Command.Left;
            commandExecutor = new LeftCommand(new LeftCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            Assert.AreEqual(0, position.Coordinates.X);
            Assert.AreEqual(0, position.Coordinates.Y);
            Assert.AreEqual(Direction.West, position.Direction);
        }

        [TestMethod]
        public void ShouldExecuteRight()
        {
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;
            commandPayload.Position = new Position();
            commandPayload.Position.Coordinates.X = 0;
            commandPayload.Position.Coordinates.Y = 0;
            commandPayload.Position.Direction = Direction.North;

            Position position = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            ICommand commandExecutor = new PlaceCommand(new PlaceCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            commandPayload.Command = Command.Right;
            commandExecutor = new RightCommand(new RightCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            Assert.AreEqual(0, position.Coordinates.X);
            Assert.AreEqual(0, position.Coordinates.Y);
            Assert.AreEqual(Direction.East, position.Direction);
        }

        [TestMethod]
        public void ShouldExecuteReport()
        {
            CommandPayload commandPayload = new CommandPayload();
            commandPayload.Command = Command.Place;
            commandPayload.Position = new Position();
            commandPayload.Position.Coordinates.X = 0;
            commandPayload.Position.Coordinates.Y = 0;
            commandPayload.Position.Direction = Direction.North;

            Position position = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            ICommand commandExecutor = new PlaceCommand(new PlaceCalculator(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4))));
            position = commandExecutor.Execute(commandPayload, position);

            commandPayload.Command = Command.Report;
            commandExecutor = new ReportCommand(new PositionValidator(new Coordinates(0, 0), new Coordinates(4, 4)), new MockGraphics());
            position = commandExecutor.Execute(commandPayload, position);

            Assert.AreEqual(0, position.Coordinates.X);
            Assert.AreEqual(0, position.Coordinates.Y);
            Assert.AreEqual(Direction.North, position.Direction);
        }

    }

    public class MockGraphics : IDisplay
    {
        public string Display(Position position)
        {
            string display = position.Coordinates.X.ToString() + ","
                + position.Coordinates.Y + ","
                + position.Direction.ToString();
            return display;
        }
    }
}
