﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Turtle.Parse;
using Turtle.Payload;
using Turtle.Enum;
using Turtle.Interface;

namespace TurtleTest
{
    [TestClass]
    public class ParserTest
    {
        [TestMethod]
        public void ShouldParsePlace()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("PLACE 0,0,NORTH");
            Assert.AreEqual(Command.Place, commandPayload.Command);
            Assert.AreEqual(0, commandPayload.Position.Coordinates.X);
            Assert.AreEqual(0, commandPayload.Position.Coordinates.Y);
            Assert.AreEqual(Direction.North, commandPayload.Position.Direction);
        }

        [TestMethod]
        public void ShouldNotParsePlaceWithSyntaxError()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("PLACE_SOMEWHERE 6,6,WHERE_EVER");
            Assert.AreEqual(Command.Invalid, commandPayload.Command);
            Assert.AreEqual(-1, commandPayload.Position.Coordinates.X);
            Assert.AreEqual(-1, commandPayload.Position.Coordinates.Y);
            Assert.AreEqual(Direction.SomeWhere, commandPayload.Position.Direction);
        }

        [TestMethod]
        public void ShouldParseMove()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("MOVE");
            Assert.AreEqual(Command.Move, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldNotParseMoveWithSyntaxError()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("MOVE_SOMEWHERE");
            Assert.AreEqual(Command.Invalid, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldParseLeft()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("LEFT");
            Assert.AreEqual(Command.Left, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldNotParseLeftWithSyntaxError()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("LEFT_SOMEWHERE");
            Assert.AreEqual(Command.Invalid, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldParseRight()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("RIGHT");
            Assert.AreEqual(Command.Right, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldNotParseRightWithSyntaxError()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("RIGHT_SOMEWHERE");
            Assert.AreEqual(Command.Invalid, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldParseReport()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("REPORT");
            Assert.AreEqual(Command.Report, commandPayload.Command);
        }

        [TestMethod]
        public void ShouldNotParseReportWithSyntaxError()
        {
            IParse parser = new Parser();
            CommandPayload commandPayload = parser.Parse("REPORT_SOMEWHERE");
            Assert.AreEqual(Command.Invalid, commandPayload.Command);
        }


    }
}
