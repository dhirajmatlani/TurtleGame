﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Enum;
using Turtle.Parse;
using Turtle.Interface;
using Turtle.Factory;
using Turtle.Payload;

namespace Turtle
{
    class Program
    {
        static void Main(string[] args)
        {
            IParse parser = new Parser();
            ICommandFactory commandFactory = new CommandFactory();
            Position currentPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);
            while (true)
            {
                string input = Console.ReadLine();
                CommandPayload commandPayload = parser.Parse(input);
                ICommand commandExecutor = commandFactory.CreateCommand(commandPayload.Command);
                currentPosition = commandExecutor.Execute(commandPayload, currentPosition);
            }
        }
    }










}
