﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;

namespace Turtle.GraphicsAdaptor
{
    public class Graphics : IDisplay
    {
        public Graphics()
        {

        }
        public string Display(Position position)
        {
            string display = position.Coordinates.X.ToString() + ","
                + position.Coordinates.Y + ","
                + position.Direction.ToString();
            Console.WriteLine(display);
            return display;
        }
    }
}
