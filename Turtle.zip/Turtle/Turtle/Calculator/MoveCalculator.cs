﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Commands;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Calculator
{
    public class MoveCalculator : ICalculate
    {
        IValidate Validator { get; set; }

        public MoveCalculator(IValidate validator)
        {
            Validator = validator;
        }
        public Position Calculate(CommandPayload commandPayload, Position currentPosition)
        {
            Position newPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            if (State.Valid == Validator.Validate(currentPosition))
            {
                newPosition.Direction = currentPosition.Direction;

                Coordinates newCoordinates = new Coordinates(currentPosition.Coordinates.X, currentPosition.Coordinates.Y);

                switch (currentPosition.Direction)
                {
                    case Direction.East:
                        newCoordinates.X = newCoordinates.X + 1;
                        break;
                    case Direction.West:
                        newCoordinates.X = newCoordinates.X - 1;
                        break;
                    case Direction.North:
                        newCoordinates.Y = newCoordinates.Y + 1;
                        break;
                    case Direction.South:
                        newCoordinates.Y = newCoordinates.Y - 1;
                        break;
                    default:
                        break;
                }
                newPosition.Coordinates = newCoordinates;

                if (State.Valid == Validator.Validate(newPosition))
                {
                    return newPosition;
                }
            }
            return currentPosition;
        }
    }
}
