﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Enum;
using Turtle.Commands;
using Turtle.Payload;

namespace Turtle.Calculator
{
    public class LeftCalculator : ICalculate
    {
        Dictionary<Direction, Dictionary<Turtle.Enum.Command, Direction>> positions;
        IValidate Validator { get; set; }

        public LeftCalculator(IValidate validator)
        {
            Validator = validator;
            positions = new Dictionary<Direction, Dictionary<Turtle.Enum.Command, Direction>>();

            Dictionary<Command, Direction> leftNorth = new Dictionary<Turtle.Enum.Command, Direction>();
            leftNorth.Add(Command.Left, Direction.North);
            positions.Add(Direction.East, leftNorth);

            Dictionary<Command, Direction> leftSouth = new Dictionary<Turtle.Enum.Command, Direction>();
            leftSouth.Add(Command.Left, Direction.South);
            positions.Add(Direction.West, leftSouth);

            Dictionary<Command, Direction> leftWest = new Dictionary<Turtle.Enum.Command, Direction>();
            leftWest.Add(Command.Left, Direction.West);
            positions.Add(Direction.North, leftWest);

            Dictionary<Command, Direction> leftEast = new Dictionary<Turtle.Enum.Command, Direction>();
            leftEast.Add(Command.Left, Direction.East);
            positions.Add(Direction.South, leftEast);
        }
        public Position Calculate(CommandPayload commandPayload, Position currentPosition)
        {
            Position newPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            if (State.Valid == Validator.Validate(currentPosition))
            {
                newPosition.Coordinates = currentPosition.Coordinates;
                newPosition.Direction = positions[currentPosition.Direction][commandPayload.Command];
            }

            if (State.Valid == Validator.Validate(newPosition))
            {
                return newPosition;
            }

            return currentPosition;
        }
    }
}
