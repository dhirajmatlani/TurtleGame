﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Calculator
{
    public class PlaceCalculator : ICalculate
    {
        IValidate Validator { get; set; }

        public PlaceCalculator(IValidate validator)
        {
            Validator = validator;
        }
        public Position Calculate(CommandPayload commandPayload, Position currentPosition)
        {
            Position newPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            if (State.Valid == Validator.Validate(commandPayload.Position))
            {
                newPosition = commandPayload.Position;
            }
            else
            {
                newPosition = currentPosition;
            }
            return newPosition;
        }
    }
}
