﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Commands;
using Turtle.Enum;
using Turtle.Payload;

namespace Turtle.Calculator
{
    public class RightCalculator : ICalculate
    {
        Dictionary<Direction, Dictionary<Command, Direction>> positions;
        IValidate Validator { get; set; }

        public RightCalculator(IValidate validator)
        {
            Validator = validator;
            positions = new Dictionary<Direction, Dictionary<Command, Direction>>();

            Dictionary<Command, Direction> rightSouth = new Dictionary<Command, Direction>();
            rightSouth.Add(Command.Right, Direction.South);
            positions.Add(Direction.East, rightSouth);

            Dictionary<Command, Direction> rightNorth = new Dictionary<Command, Direction>();
            rightNorth.Add(Command.Right, Direction.North);
            positions.Add(Direction.West, rightNorth);

            Dictionary<Command, Direction> Righteast = new Dictionary<Command, Direction>();
            Righteast.Add(Command.Right, Direction.East);
            positions.Add(Direction.North, Righteast);

            Dictionary<Command, Direction> rightWest = new Dictionary<Command, Direction>();
            rightWest.Add(Command.Right, Direction.West);
            positions.Add(Direction.South, rightWest);

        }
        public Position Calculate(CommandPayload commandPayload, Position currentPosition)
        {
            Position newPosition = new Position(new Coordinates(-1, -1), Direction.SomeWhere);

            if (State.Valid == Validator.Validate(currentPosition))
            {
                newPosition.Coordinates = currentPosition.Coordinates;
                newPosition.Direction = positions[currentPosition.Direction][commandPayload.Command];
            }

            if (State.Valid == Validator.Validate(newPosition))
            {
                return newPosition;
            }

            return newPosition;
        }
    }
}
