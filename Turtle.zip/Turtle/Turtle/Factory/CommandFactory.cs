﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Commands;
using Turtle.Enum;
using Turtle.Calculator;
using Turtle.Validator;
using Turtle.GraphicsAdaptor;

namespace Turtle.Factory
{
    public class CommandFactory : ICommandFactory
    {
        private Dictionary<Command, ICommand> mapCommandToExecutor = new Dictionary<Command, ICommand>();

        public CommandFactory()
        {
            mapCommandToExecutor.Add(Command.Place, new PlaceCommand(new PlaceCalculator(new PositionValidator(new Payload.Coordinates(0, 0), new Payload.Coordinates(4,4)))));
            mapCommandToExecutor.Add(Command.Move, new MoveCommand(new MoveCalculator(new PositionValidator(new Payload.Coordinates(0, 0), new Payload.Coordinates(4, 4)))));
            mapCommandToExecutor.Add(Command.Left, new LeftCommand(new LeftCalculator(new PositionValidator(new Payload.Coordinates(0, 0), new Payload.Coordinates(4, 4)))));
            mapCommandToExecutor.Add(Command.Right, new RightCommand(new RightCalculator(new PositionValidator(new Payload.Coordinates(0, 0), new Payload.Coordinates(4, 4)))));
            mapCommandToExecutor.Add(Command.Report, new ReportCommand(new PositionValidator(new Payload.Coordinates(0, 0), new Payload.Coordinates(4, 4)), new Graphics()));
        }
        public virtual ICommand CreateCommand(Command command)
        {
            return mapCommandToExecutor[command];
        }
    }
}
