﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Parse
{
    public class Parser : IParse
    {
        private Dictionary<string, Direction> directions = new Dictionary<string, Direction>();
        private Dictionary<string, Command> commands = new Dictionary<string, Command>();
        
        public Parser()
        {
            directions.Add(Direction.East.ToString().ToUpper(), Direction.East);
            directions.Add(Direction.West.ToString().ToUpper(), Direction.West);
            directions.Add(Direction.North.ToString().ToUpper(), Direction.North);
            directions.Add(Direction.South.ToString().ToUpper(), Direction.South);

            commands.Add(Command.Place.ToString().ToUpper(), Command.Place);
            commands.Add(Command.Move.ToString().ToUpper(), Command.Move);
            commands.Add(Command.Left.ToString().ToUpper(), Command.Left);
            commands.Add(Command.Right.ToString().ToUpper(), Command.Right);
            commands.Add(Command.Report.ToString().ToUpper(), Command.Report);
        }
        public CommandPayload Parse(string input)
        {
            return ParseCommandPayload(input);
        }

        public CommandPayload ParseCommandPayload(string payload)
        {
            CommandPayload commandPayload = new CommandPayload();
            string[] payloadSubset = payload.Split(new char[] { ' ' });
            string command = null;
            if (payloadSubset == null || payloadSubset.Length == 0)
            {
                command = payload;
            }
            else
            {
                command = payloadSubset[0];
            }

            command = command.Trim();
            if (commands.ContainsKey(command.ToUpper()))
                commandPayload.Command = commands[command.ToUpper()];
            else
                commandPayload.Command = Command.Invalid;

            commandPayload.Position = new Position();

            if (Command.Place == commandPayload.Command)
            {
                string[] position = payloadSubset[1].Split(new char[] { ',' });

                position[0] = position[0].Trim();
                position[1] = position[1].Trim();
                position[2] = position[2].Trim();

                commandPayload.Position.Coordinates.X = Convert.ToInt32(position[0]);
                commandPayload.Position.Coordinates.Y = Convert.ToInt32(position[1]);

                if (directions.ContainsKey(position[2].ToUpper()))
                    commandPayload.Position.Direction = directions[position[2].ToUpper()];
                else
                    commandPayload.Position.Direction = Direction.SomeWhere;
            }
            else
            {
                commandPayload.Position.Coordinates.X = -1;
                commandPayload.Position.Coordinates.Y = -1;
                commandPayload.Position.Direction = Direction.SomeWhere;
            }

            return commandPayload;
        }
    }
}
