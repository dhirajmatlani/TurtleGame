﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Enum;

namespace Turtle.Payload
{
    public class Position
    {
        public Enum.Direction Direction { get; set; }

        public Coordinates Coordinates { get; set; }

        public Position(Coordinates coordinates, Direction direction)
        {
            Coordinates = coordinates;
            Direction = direction;
        }

        public Position()
        {
            Coordinates = new Coordinates();
            Direction = new Direction();
        }
    }
}
