﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Enum;

namespace Turtle.Payload
{
    public class CommandPayload
    {
        public Turtle.Enum.Command Command { get; set; }

        public Position Position { get; set; }
    }
}
