﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Validator
{
    public class PositionValidator : IValidate
    {
        public Coordinates MinCordinates { get; set; }

        public Coordinates MaxCoordinates { get; set; }
        public PositionValidator(Coordinates minCordinates, Coordinates maxCoordinates)
        {
            MinCordinates = minCordinates;
            MaxCoordinates = maxCoordinates;
        }

        public PositionValidator()
        {
        }

        public bool IsValid(Coordinates coordinates)
        {
            bool isValid = false;
            if (coordinates.X >= MinCordinates.X && coordinates.X <= MaxCoordinates.X)
            {
                if (coordinates.Y >= MinCordinates.Y && coordinates.Y <= MaxCoordinates.Y)
                {
                    isValid = true;
                }
            }
            return isValid;
        }

        public bool IsValid(Direction direction)
        {
            bool isValid = false;
            if (direction == Direction.East || direction == Direction.West || direction == Direction.North || direction == Direction.South)
            {
                isValid = true;
            }
            return isValid;
        }

        public State Validate(Position position)
        {
            if (IsValid(position.Coordinates) && IsValid(position.Direction))
            {
                return State.Valid;
            }
            return State.Invalid;
        }
    }
}
