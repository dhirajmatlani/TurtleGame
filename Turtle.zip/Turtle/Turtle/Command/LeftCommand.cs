﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;

namespace Turtle.Commands
{
    public class LeftCommand : ICommand
    {
        ICalculate LeftCalculator { get; set; }

        public LeftCommand(ICalculate leftCalculator)
        {
            LeftCalculator = leftCalculator;
        }

        public Position Execute(CommandPayload commandPayload, Position currentPosition)
        {
            return LeftCalculator.Calculate(commandPayload, currentPosition);
        }
    }
}
