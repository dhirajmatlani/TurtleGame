﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Commands
{
    public class ReportCommand : ICommand
    {
        IDisplay Graphics { get; set; }
        IValidate Validator { get; set; }
        public ReportCommand(IValidate validator, IDisplay graphics)
        {
            Graphics = graphics;
            Validator = validator;
        }

        public Position Execute(CommandPayload commandPayload, Position currentPosition)
        {
            if (State.Valid == Validator.Validate(currentPosition))
            {
                Graphics.Display(currentPosition);
            }
            return currentPosition;
        }
    }
}
