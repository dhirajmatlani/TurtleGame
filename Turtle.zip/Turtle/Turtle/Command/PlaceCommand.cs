﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Interface;
using Turtle.Payload;

namespace Turtle.Commands
{
    public class PlaceCommand : ICommand
    {
        ICalculate PlaceCalculator { get; set; }

        public PlaceCommand(ICalculate placeCalculator)
        {
            PlaceCalculator = placeCalculator;
        }

        public Position Execute(CommandPayload commandPayload, Position currentPosition)
        {
            return PlaceCalculator.Calculate(commandPayload, currentPosition);
        }
    }
}
