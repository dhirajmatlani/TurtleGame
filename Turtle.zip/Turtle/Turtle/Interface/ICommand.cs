﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Enum;
using Turtle.Payload;

namespace Turtle.Interface
{
    public interface ICommand
    {
        Position Execute(CommandPayload commandPayload, Position currentPosition);
    }
}
