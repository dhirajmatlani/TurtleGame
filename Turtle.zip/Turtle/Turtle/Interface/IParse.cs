﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Payload;

namespace Turtle.Interface
{
    public interface IParse
    {
        CommandPayload Parse(string input);
    }
}
