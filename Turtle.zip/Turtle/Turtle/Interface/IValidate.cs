﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Payload;
using Turtle.Enum;

namespace Turtle.Interface
{
    public interface IValidate
    {
        State Validate(Position position);
    }

}
