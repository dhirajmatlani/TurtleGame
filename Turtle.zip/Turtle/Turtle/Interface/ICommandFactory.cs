﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turtle.Enum;

namespace Turtle.Interface
{
    public interface ICommandFactory
    {
        ICommand CreateCommand(Turtle.Enum.Command command);
    }
}
